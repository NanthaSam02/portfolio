import "./Projects.css";

function Projects() {
  return (
    <section className="projects" id="projects">
      <h2>Projects</h2>

      <div className="projects-grid">
        {/* Project 1 */}
        <div className="project-card">
          <img src="/project1.jpg" alt="project" />
          <div className="project-content">
            <h3>Portfolio Website</h3>
            <p>
              A modern, fully responsive personal portfolio built using React.js
              with smooth scrolling and clean UI.
            </p>
            <div className="tech-stack">
              <span>React</span>
              <span>CSS</span>
              <span>JavaScript</span>
            </div>
            <div className="project-links">
              <a href="#" target="_blank">Live</a>
              <a href="#" target="_blank">GitHub</a>
            </div>
          </div>
        </div>

        {/* Project 2 */}
        <div className="project-card">
          <img src="/project2.jpg" alt="project" />
          <div className="project-content">
            <h3>E-Commerce Website</h3>
            <p>
              Mushroom selling e-commerce website with product listing, admin
              panel and responsive design.
            </p>
            <div className="tech-stack">
              <span>React</span>
              <span>PHP</span>
              <span>MySQL</span>
            </div>
            <div className="project-links">
              <a href="#" target="_blank">Live</a>
              <a href="#" target="_blank">GitHub</a>
            </div>
          </div>
        </div>

        {/* Project 3 */}
        <div className="project-card">
          <img src="/project3.jpg" alt="project" />
          <div className="project-content">
            <h3>Petty Cash System</h3>
            <p>
              Web application to manage daily expenses with reports and
              user-friendly UI.
            </p>
            <div className="tech-stack">
              <span>Laravel</span>
              <span>Bootstrap</span>
              <span>MySQL</span>
            </div>
            <div className="project-links">
              <a href="#" target="_blank">Live</a>
              <a href="#" target="_blank">GitHub</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Projects;