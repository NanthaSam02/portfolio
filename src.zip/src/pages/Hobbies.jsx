import "./Hobbies.css";

function Hobbies() {
  return (
    <section className="hobbies" id="hobbies">
      <h2>Hobbies</h2>

      <div className="hobbies-grid">
        <div className="hobby-card">
          <span className="emoji">💻</span>
          <h3>Coding</h3>
          <p>Building clean UI and learning new web technologies.</p>
        </div>

        <div className="hobby-card">
          <span className="emoji">🎨</span>
          <h3>Designing</h3>
          <p>UI/UX design, banners, posters and creative layouts.</p>
        </div>

        <div className="hobby-card">
          <span className="emoji">📸</span>
          <h3>Photography</h3>
          <p>Capturing moments and editing creative visuals.</p>
        </div>

        <div className="hobby-card">
          <span className="emoji">📚</span>
          <h3>Learning</h3>
          <p>Exploring new tools, frameworks and technologies.</p>
        </div>
      </div>
    </section>
  );
}

export default Hobbies;