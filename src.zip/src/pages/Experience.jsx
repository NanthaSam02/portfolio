import "./Experience.css";

function Experience() {
  return (
    <section className="experience" id="experience">
      {/* HEADER */}
      <div className="exp-header">
        <h2>Experience</h2>
        <span>(02)</span>
      </div>

      <hr className="exp-line" />

      {/* EXPERIENCE LIST */}
      <div className="exp-list">

        {/* ITEM 1 */}
        <div className="exp-item">
          <div className="exp-left">
            <h3>2024 – Present</h3>
            <p>Reactjs Developer</p>
          </div>

          <div className="exp-middle">
            <span className="dot active"></span>
            <div className="line"></div>
          </div>

          <div className="exp-right">
            <h4>Homewala.com</h4>
            <small>Full-time</small>
            <p>
              Working on real-world React applications for a real estate platform,
              developing responsive UI components, maintaining live projects,
              integrating data, and improving performance and SEO for better
              lead generation.
            </p>
          </div>
        </div>

        {/* ITEM 2 */}
        <div className="exp-item">
          <div className="exp-left">
            <h3>2023 – 2024</h3>
            <p>Web Designer </p>
          </div>

          <div className="exp-middle">
            <span className="dot"></span>
            <div className="line"></div>
          </div>

          <div className="exp-right">
            <h4>Innovias24</h4>
            <small>Full-time</small>
            <p>
              Designed and developed responsive websites using Figma, HTML, CSS,
              and React. Worked on website maintenance, UI improvements, SEO
              updates, and supported lead generation activities.
            </p>
          </div>
        </div>

        {/* ITEM 3 */}
        <div className="exp-item">
          <div className="exp-left">
            <h3>2024</h3>
            <p>UI Ux Course </p>
          </div>

          <div className="exp-middle">
            <span className="dot"></span>
          </div>

          <div className="exp-right">
            <h4>Pumo Technovation</h4>
            <small>certificate course</small>
            <p>
              Built projects like a petty cash management system using React and
              PHP Laravel, along with business and landing websites focused on
              usability, clean design, and basic SEO optimization.
            </p>
          </div>
        </div>
         {/* ITEM 4 */}
<div className="exp-item">
          <div className="exp-left">
            <h3>2023</h3>
            <p>Web Developer (Internship)</p>
          </div>

          <div className="exp-middle">
            <span className="dot"></span>
          </div>

          <div className="exp-right">
            <h4>Pcs Software Solutions</h4>
            <small>Internship</small>
            <p>
              Learn Basic HTML,CSS and Basic Javascript and 
            </p>
          </div>
        </div>

      </div>
    </section>
  );
}

export default Experience;