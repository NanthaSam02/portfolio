import "./Skills.css";

function Skills() {
  return (
    <section className="skills" id="skills">
      <h2>Skills</h2>

      <div className="skills-grid">
        <div className="skill-card">React.js</div>
        <div className="skill-card">JavaScript</div>
        <div className="skill-card">HTML5</div>
        <div className="skill-card">CSS3</div>
        <div className="skill-card">Bootstrap</div>
        <div className="skill-card">Tailwind CSS</div>
        <div className="skill-card">PHP</div>
        <div className="skill-card">Laravel</div>
        <div className="skill-card">MySQL</div>
        <div className="skill-card">Git & GitHub</div>
      </div>
    </section>
  );
}

export default Skills;